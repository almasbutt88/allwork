package com.codeclan.example.CourseBookingSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseBookingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CourseBookingSystemApplication.class, args);
	}

}
