package com.codeclan.example.Workout.Tracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkoutTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
